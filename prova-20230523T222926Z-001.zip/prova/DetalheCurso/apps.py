from django.apps import AppConfig


class DetalhecursoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DetalheCurso'
